<template>
  <div class="container mt-5">
    <div v-for="article in articles" :key="article.id">
      <h2>
        <router-link
          class="link-style"
          :to="{ name: 'details', params: { id: article.id } }"
        >
          {{ article.title }}记录时间：{{ article.date }}
        </router-link>
      </h2>
      <hr />
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      articles: [],
    };
  },
  methods: {
    getArticles() {
      fetch("http://localhost:5000/get", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      })
        .then((resp) => resp.json())
        .then((data) => {
          //console.log(data);
          this.articles.push(...data);
        })
        .catch((error) => {
          console.log(error);
        });
    },
  },

  created() {
    this.getArticles();
  },
};
</script>

<style>
.link-style {
  font-weight: bold;
  color: goldenrod;
  text-decoration: none;
}

.link-style:hover {
  color: greenyellow;
  text-decoration: none;
}
</style>
