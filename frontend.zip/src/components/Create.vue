<template>
  <div class="container mt-4">
    <form>
      <input
        type="text"
        class="form-control"
        placeholder="Please enter your title"
        v-model="title"
      />
      <br />

      <textarea
        class="form-control"
        placeholder="Please enter your body"
        v-model="body"
      >
      </textarea>

      <button class="btn btn-success mt-4">Confirm record</button>
    </form>
  </div>
</template>

<script>
export default {
  data() {
    return {
      title: null,
      body: null,
      error: null,
    };
  },
};
</script>

<style></style>
